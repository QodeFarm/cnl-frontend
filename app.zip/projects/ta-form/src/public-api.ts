/*
 * Public API Surface of ta-form
 */

export * from './lib/ta-form.service';
export * from './lib/ta-form.component';
export * from './lib/ta-form.module';
export * from './lib/ta-form-config';
export * from './ta-formly-ui-zero/fields/ta-field-input/ta-field-input.module';
