/*
 * Public API Surface of ta-table
 */
export * from './lib/ta-table.service';
export * from './lib/ta-table.component';
export * from './lib/ta-filters/ta-filters.component';
export * from './lib/ta-filters/date-range-filter/date-range-filter.component';
export * from './lib/ta-table.module';
export * from './lib/ta-table-config';