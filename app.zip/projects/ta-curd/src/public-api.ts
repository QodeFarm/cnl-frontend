/*
 * Public API Surface of ta-curd
 */

export * from './lib/ta-curd.service';
export * from './lib/ta-curd.component';
export * from './lib/ta-curd.module';
export * from './lib/ta-curd-config';
