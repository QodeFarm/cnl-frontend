import { TaImgPipe } from './ta-img.pipe';

describe('TaImgPipe', () => {
  it('create an instance', () => {
    const pipe = new TaImgPipe();
    expect(pipe).toBeTruthy();
  });
});
